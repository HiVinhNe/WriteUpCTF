docker run --privileged -d -p 1337 $(docker build -q .) && docker ps
